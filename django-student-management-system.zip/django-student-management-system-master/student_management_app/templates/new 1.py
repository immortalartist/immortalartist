def toString(List): 
	return ''.join(List) 
# Function to print permutations of string 
# This function takes three parameters: 
# 1. String 
# 2. Starting index of the string 
# 3. Ending index of the string. 
def permute(a, l, r): 
	if l==r: 
		print toString(a) 
	else: 
		for i in xrange(l,r+1): 
			a[l], a[i] = a[i], a[l] 
			permute(a, l+1, r) 
			a[l], a[i] = a[i], a[l] # backtrack 

string = list(map(input().split("")))
n = len(string) 
a = list(string) 
permute(a, 0, n-1)

def generatePermutation(string,start,end):  
    current = 0;  
    start=0
    n=len(str)
    #Prints the permutations  
    if(start == end-1):  
        print(string);  
    else:   
        for current in range(start,end):  
  
       #Swapping the string by fixing a character  
            x = list(string);  
            temp = x[start];  
            x[start] = x[current];  
            x[current] = temp;  
  
      #Recursively calling function generatePermutation() for rest of the characters  
  
            generatePermutation("".join(x),start+1,end);  
            #Swapping the string by fixing a character  
            temp = x[start];  
            x[start] = x[current];  
            x[current] = temp;  
  
str = "ABC"  
n = len(str);  
print("All the permutations of the string are: ");  
generatePermutation(str,0,n);































